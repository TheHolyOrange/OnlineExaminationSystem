package main.java.com.exam;

import java.util.Scanner;

public abstract class User {
    protected String username;
    protected String email;
    protected String role;

    public User(String username, String email, String role) {
        this.username = username;
        this.email = email;
        this.role = role;
    }

    public String getUsername() {
        return username;
    }

    public String getEmail() {
        return email;
    }

    public String getRole() {
        return role;
    }

        // Sign In Method
    public static boolean signIn(ExamSystem system, Scanner scanner, String role) {
        System.out.print("Enter your email: ");
        String email = scanner.nextLine();

        System.out.print("Enter your username: ");
        String username = scanner.nextLine();

        for (User user : system.users) {
            if (user.getEmail().equalsIgnoreCase(email) &&
                user.getUsername().equalsIgnoreCase(username) &&
                user.getRole().equalsIgnoreCase(role)) {
                System.out.println("Welcome, " + user.getUsername() + "! Signed in as " + role + ".");
                return true;
            }
        }

        System.out.println("User not found or wrong credentials.");
        return false;
    }

    // Sign Up Method
    public static void signUp(ExamSystem system, Scanner scanner, String role) {
        System.out.print("Enter a username: ");
        String username = scanner.nextLine();

        String email = "";
        while (true) {
            System.out.print("Enter your email: ");
            email = scanner.nextLine();
            if (isValidEmail(email)) {
                break;
            } else {
                System.out.println("Invalid email format. Please try again.");
            }
        }

        if (role.equalsIgnoreCase("Admin")) {
            Admin admin = new Admin(username, email);
            system.addUser(admin);
        } else if (role.equalsIgnoreCase("Student")) {
            Student student = new Student(username, email);
            system.addUser(student);
        }

        system.saveUserToCSV(); // Save the new user to CSV
        System.out.println("Sign up successful. You can now sign in.");
    }

    // Simple email validation
    private static boolean isValidEmail(String email) {
        return email.contains("@") && email.contains(".");
    }
}
