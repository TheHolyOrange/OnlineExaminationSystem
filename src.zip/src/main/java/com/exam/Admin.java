package main.java.com.exam;
import java.util.Iterator;
import java.util.Scanner;

public class Admin extends User {

    public Admin(String username, String email) {
        super(username, email, "Admin");
    }

    public static void handleAdminMenu(ExamSystem system, Scanner scanner) {
        System.out.println("\nAdmin Menu:");
        System.out.println("1. Sign In");
        System.out.println("2. Sign Up");
        System.out.println("3. Back to Main Menu");
        System.out.print("Enter your choice: ");

        if (scanner.hasNextInt()) {
            int adminChoice = scanner.nextInt();
            scanner.nextLine();  // Consume the newline

            switch (adminChoice) {
                case 1:
                    if (User.signIn(system, scanner, "Admin")) {
                        adminActions(system, scanner);
                    }
                    break;
                case 2:
                    User.signUp(system, scanner, "Admin");
                    break;
                case 3:
                    System.out.println("Returning to Main Menu...");
                    break;
                default:
                    System.out.println("Invalid choice.");
            }
        } else {
            System.out.println("Invalid input. Returning to main menu.");
            scanner.nextLine();  // Flush invalid input
        }
    }

    private static void adminActions(ExamSystem system, Scanner scanner) {
        boolean logout = false;

        while (!logout) {
            System.out.println("\nAdmin Actions:");
            System.out.println("1. Create Question");
            System.out.println("2. Configure Exam");
            System.out.println("3. View Student Performances");
            System.out.println("4. Update Question");  // New option for updating a question
            System.out.println("5. Delete Question");  // New option for deleting a question
            System.out.println("6. Logout");
            System.out.print("Enter your choice: ");

            if (scanner.hasNextInt()) {
                int adminActionChoice = scanner.nextInt();
                scanner.nextLine();  // Consume newline

                switch (adminActionChoice) {
                    case 1:
                        createQuestion(system, scanner);
                        break;
                    case 2:
                        configureExam(system, scanner);
                        break;
                    case 3:
                        system.displayResultsForAdmin();
                        break;
                    case 4:
                        updateQuestion(system, scanner);  // Call the method to update a question
                        break;
                    case 5:
                        deleteQuestion(system, scanner);  // Call the method to delete a question
                        break;
                    case 6:
                        System.out.println("Logging out...");
                        logout = true;
                        break;
                    default:
                        System.out.println("Invalid choice.");
                }
            } else {
                System.out.println("Invalid input.");
                scanner.nextLine();  // Flush invalid input
            }
        }
    }

    private static void createQuestion(ExamSystem system, Scanner scanner) {
        System.out.print("Enter question text: ");
        String questionText = scanner.nextLine();

        System.out.print("Enter options separated by ';' (e.g., option1;option2;option3;option4): ");
        String optionsInput = scanner.nextLine();
        String[] options = optionsInput.split(";");

        int correctAnswerIndex = -1;
        while (true) {
            System.out.print("Enter the index of the correct answer (starting from 1): ");
            if (scanner.hasNextInt()) {
                correctAnswerIndex = scanner.nextInt();
                scanner.nextLine();  // Consume newline
                if (correctAnswerIndex >= 1 && correctAnswerIndex <= options.length) {
                    break;
                } else {
                    System.out.println("Please enter a valid index between 1 and " + options.length + ".");
                }
            } else {
                System.out.println("Invalid input. Please enter a number.");
                scanner.nextLine();  // Flush invalid input
            }
        }

        System.out.print("Enter question category: ");
        String category = scanner.nextLine();

        System.out.print("Enter difficulty (Easy/Medium/Hard): ");
        String difficulty = scanner.nextLine();

        Question question = new Question(questionText, options, correctAnswerIndex, category, difficulty);
        system.addQuestion(question);
        system.saveQuestionsToCSV(); // Save the new question to CSV

        System.out.println("Question created and saved successfully.");
    }

    private static void configureExam(ExamSystem system, Scanner scanner) {
        // Placeholder for exam configuration logic
        System.out.println("Configure Exam:");
        System.out.println("1. Create a new exam");
        System.out.println("2. Modify existing exam");
        System.out.println("3. Back to Admin Actions");
        System.out.print("Enter your choice: ");

        if (scanner.hasNextInt()) {
            int configChoice = scanner.nextInt();
            scanner.nextLine();  // Consume newline

            switch (configChoice) {
                case 1:
                    createNewExam(system, scanner);
                    break;
                case 2:
                    // Implement modify exam functionality as needed
                    System.out.println("Modify Exam feature is under development.");
                    break;
                case 3:
                    System.out.println("Returning to Admin Actions.");
                    break;
                default:
                    System.out.println("Invalid choice.");
            }
        } else {
            System.out.println("Invalid input.");
            scanner.nextLine();  // Flush invalid input
        }
    }

    private static void createNewExam(ExamSystem system, Scanner scanner) {
        System.out.print("Enter exam category: ");
        String category = scanner.nextLine();

        int numberOfQuestions = -1;
        while (true) {
            System.out.print("Enter number of questions: ");
            if (scanner.hasNextInt()) {
                numberOfQuestions = scanner.nextInt();
                scanner.nextLine();  // Consume newline
                if (numberOfQuestions > 0) {
                    break;
                } else {
                    System.out.println("Number of questions must be positive.");
                }
            } else {
                System.out.println("Invalid input. Please enter a number.");
                scanner.nextLine();  // Flush invalid input
            }
        }

        int duration = -1;
        while (true) {
            System.out.print("Enter exam duration in minutes: ");
            if (scanner.hasNextInt()) {
                duration = scanner.nextInt();
                scanner.nextLine();  // Consume newline
                if (duration > 0) {
                    break;
                } else {
                    System.out.println("Duration must be positive.");
                }
            } else {
                System.out.println("Invalid input. Please enter a number.");
                scanner.nextLine();  // Flush invalid input
            }
        }

        Exam exam = system.createExam(category, numberOfQuestions, duration);
        if (exam != null) {
            System.out.println("Exam created successfully.");
        } else {
            System.out.println("Failed to create exam. Please check the category and number of questions.");
        }
    }

    private static void updateQuestion(ExamSystem system, Scanner scanner) {
        System.out.print("Enter the text of the question you want to update: ");
        String questionText = scanner.nextLine();

        Question questionToUpdate = null;
        for (Question question : system.questionRepository) {
            if (question.getQuestionText().equalsIgnoreCase(questionText)) {
                questionToUpdate = question;
                break;
            }
        }

        if (questionToUpdate == null) {
            System.out.println("Question not found.");
            return;
        }

        // Update question text
        System.out.print("Enter new question text (leave blank to keep current): ");
        String newQuestionText = scanner.nextLine();
        if (!newQuestionText.trim().isEmpty()) {
            questionToUpdate.setQuestionText(newQuestionText);
        }

        // Update options
        System.out.print("Enter new options separated by ';' (leave blank to keep current): ");
        String newOptionsInput = scanner.nextLine();
        if (!newOptionsInput.trim().isEmpty()) {
            questionToUpdate.setOptions(newOptionsInput.split(";"));
        }

        // Update correct answer index
        System.out.print("Enter new correct answer index (starting from 1): ");
        if (scanner.hasNextInt()) {
            int newCorrectAnswerIndex = scanner.nextInt();
            scanner.nextLine();  // Consume newline
            questionToUpdate.setCorrectAnswerIndex(newCorrectAnswerIndex);
        } else {
            System.out.println("Invalid input for correct answer index.");
            scanner.nextLine();  // Flush invalid input
        }

        // Update category
        System.out.print("Enter new question category (leave blank to keep current): ");
        String newCategory = scanner.nextLine();
        if (!newCategory.trim().isEmpty()) {
            questionToUpdate.setCategory(newCategory);
        }

        // Update difficulty
        System.out.print("Enter new difficulty (Easy/Medium/Hard): ");
        String newDifficulty = scanner.nextLine();
        if (!newDifficulty.trim().isEmpty()) {
            questionToUpdate.setDifficulty(newDifficulty);
        }

        system.saveQuestionsToCSV();  // Save changes to the CSV file
        System.out.println("Question updated successfully.");
    }

    private static void deleteQuestion(ExamSystem system, Scanner scanner) {
        System.out.print("Enter the text of the question you want to delete: ");
        String questionText = scanner.nextLine();

        boolean questionFound = false;
        Iterator<Question> iterator = system.questionRepository.iterator();
        while (iterator.hasNext()) {
            Question question = iterator.next();
            if (question.getQuestionText().equalsIgnoreCase(questionText)) {
                iterator.remove();  // Remove the question
                questionFound = true;
                break;
            }
        }

        if (!questionFound) {
            System.out.println("Question not found.");
            return;
        }

        system.saveQuestionsToCSV();  // Save changes to the CSV file
        System.out.println("Question deleted successfully.");
    }
}
