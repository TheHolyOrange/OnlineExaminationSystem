package main.java.com.exam;

import java.io.*;
import java.util.*;

public class ExamSystem {

    public List<Question> questionRepository = new ArrayList<>();
    public List<User> users = new ArrayList<>();
    public List<Result> results = new ArrayList<>();

    private static final String QUESTIONS_FILE = "src/main/resources/questions.csv";
    private static final String USERS_FILE = "src/main/resources/users.csv";
    private static final String RESULTS_FILE = "src/main/resources/results.csv";

    // Load questions from CSV
    public void loadQuestionsFromCSV(String filePath) throws IOException {
        BufferedReader br = new BufferedReader(new FileReader(filePath));
        String line;
        while ((line = br.readLine()) != null) {
            String[] values = line.split(",");
            String text = values[0];
            String[] options = values[1].split(";");
            int correctAnswerIndex = Integer.parseInt(values[2]);
            String category = values[3];
            String difficulty = values[4];

            Question question = new Question(text, options, correctAnswerIndex, category, difficulty);
            questionRepository.add(question);
        }
        br.close();
    }

    // Save questions to CSV
    public void saveQuestionsToCSV() {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(QUESTIONS_FILE))) {
            for (Question q : questionRepository) {
                writer.write(q.getQuestionText() + "," + String.join(";", q.getOptions()) + "," +
                             q.getCorrectAnswerIndex() + "," + q.getCategory() + "," + q.getDifficulty());
                writer.newLine();
            }
        } catch (IOException e) {
            System.out.println("Error saving questions.");
            e.printStackTrace();
        }
    }
    

    // Load users from CSV
    public void loadUsersFromCSV(String filePath) throws IOException {
        BufferedReader br = new BufferedReader(new FileReader(filePath));
        String line;
        while ((line = br.readLine()) != null) {
            String[] values = line.split(",");
            String username = values[0];
            String email = values[1];
            String role = values[2];

            if ("Admin".equalsIgnoreCase(role)) {
                Admin admin = new Admin(username, email);
                users.add(admin);
            } else if ("Student".equalsIgnoreCase(role)) {
                Student student = new Student(username, email);
                users.add(student);
            }
        }
        br.close();
    }

    // Save users to CSV
    public void saveUserToCSV() {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(USERS_FILE))) {
            for (User user : users) {
                writer.write(user.getUsername() + "," + user.getEmail() + "," + user.getRole());
                writer.newLine();
            }
        } catch (IOException e) {
            System.out.println("Error saving users.");
            e.printStackTrace();
        }
    }

    // Load results from CSV
    public void loadResultsFromCSV() {
        File file = new File(RESULTS_FILE);
        if (!file.exists()) {
            // If the results file doesn't exist, create it
            try {
                file.createNewFile();
            } catch (IOException e) {
                System.out.println("Error creating results file.");
                e.printStackTrace();
                return;
            }
        }

        try (BufferedReader br = new BufferedReader(new FileReader(RESULTS_FILE))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] values = line.split(",");
                if (values.length != 6) continue; // Skip invalid lines

                String studentName = values[0];
                String examCategory = values[1];
                int totalQuestions = Integer.parseInt(values[2]);
                int correctAnswers = Integer.parseInt(values[3]);
                int incorrectAnswers = Integer.parseInt(values[4]);
                String examDate = values[5];

                Result result = new Result(studentName, examCategory, totalQuestions, correctAnswers, incorrectAnswers, examDate);
                results.add(result);
            }
        } catch (IOException e) {
            System.out.println("Error loading results.");
            e.printStackTrace();
        }
    }

    // Save a single result to CSV
    public void saveResultToCSV(Result result) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(RESULTS_FILE, true))) {
            writer.write(result.toString());
            writer.newLine();
        } catch (IOException e) {
            System.out.println("Error saving result.");
            e.printStackTrace();
        }
    }

    // Add a user
    public void addUser(User user) {
        users.add(user);
    }

    // Add a question
    public void addQuestion(Question question) {
        questionRepository.add(question);
    }

    // Create an exam based on subject category
    public Exam createExam(String category, int numberOfQuestions, int duration) {
        List<Question> selectedQuestions = new ArrayList<>();
        Random rand = new Random();

        // Filter questions by category
        List<Question> filteredQuestions = new ArrayList<>();
        for (Question q : questionRepository) {
            if (q.getCategory().equalsIgnoreCase(category)) {
                filteredQuestions.add(q);
            }
        }

        // Check if there are enough questions
        if (filteredQuestions.size() < numberOfQuestions) {
            System.out.println("Not enough questions available for the selected category.");
            return null; // Or handle it as needed
        }

        // Shuffle the filtered questions
        Collections.shuffle(filteredQuestions, rand);

        // Select the required number of questions
        for (int i = 0; i < numberOfQuestions; i++) {
            selectedQuestions.add(filteredQuestions.get(i));
        }

        return new Exam(selectedQuestions, duration);
    }

    // Display all results for admin
    public void displayResultsForAdmin() {
        if (results.isEmpty()) {
            System.out.println("\nNo exam results found.");
            return;
        }

        System.out.println("\n--- Students' Exam Performances ---");
        for (Result result : results) {
            System.out.println("Student Name: " + result.getStudentName());
            System.out.println("Exam Category: " + result.getExamCategory());
            System.out.println("Total Questions: " + result.getTotalQuestions());
            System.out.println("Correct Answers: " + result.getCorrectAnswers());
            System.out.println("Incorrect Answers: " + result.getIncorrectAnswers());
            System.out.println("Exam Date: " + result.getExamDate());
            System.out.println("-----------------------------------");
        }
    }
}
