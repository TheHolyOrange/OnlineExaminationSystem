package main.java.com.exam;

public class Result {
    private String studentName;
    private String examCategory;
    private int totalQuestions;
    private int correctAnswers;
    private int incorrectAnswers;
    private String examDate;

    public Result(String studentName, String examCategory, int totalQuestions, int correctAnswers, int incorrectAnswers, String examDate) {
        this.studentName = studentName;
        this.examCategory = examCategory;
        this.totalQuestions = totalQuestions;
        this.correctAnswers = correctAnswers;
        this.incorrectAnswers = incorrectAnswers;
        this.examDate = examDate;
    }

    public String getStudentName() {
        return studentName;
    }

    public String getExamCategory() {
        return examCategory;
    }

    public int getTotalQuestions() {
        return totalQuestions;
    }

    public int getCorrectAnswers() {
        return correctAnswers;
    }

    public int getIncorrectAnswers() {
        return incorrectAnswers;
    }

    public String getExamDate() {
        return examDate;
    }

    @Override
    public String toString() {
        return studentName + "," + examCategory + "," + totalQuestions + "," + correctAnswers + "," + incorrectAnswers + "," + examDate;
    }
}
