package main.java.com.exam;

import java.util.Scanner;

public class Student extends User {

    public Student(String username, String email) {
        super(username, email, "Student");
    }

    public static void handleStudentMenu(ExamSystem system, Scanner scanner) {
        System.out.println("\nStudent Menu:");
        System.out.println("1. Sign In");
        System.out.println("2. Sign Up");
        System.out.println("3. Back to Main Menu");
        System.out.print("Enter your choice: ");

        if (scanner.hasNextInt()) {
            int studentChoice = scanner.nextInt();
            scanner.nextLine();  // Consume the newline

            switch (studentChoice) {
                case 1:
                    if (User.signIn(system, scanner, "Student")) {
                        studentActions(system, scanner);
                    }
                    break;
                case 2:
                    User.signUp(system, scanner, "Student");
                    break;
                case 3:
                    System.out.println("Returning to Main Menu...");
                    break;
                default:
                    System.out.println("Invalid choice.");
            }
        } else {
            System.out.println("Invalid input. Returning to main menu.");
            scanner.nextLine();  // Flush invalid input
        }
    }

    // Handle Student Actions
    private static void studentActions(ExamSystem system, Scanner scanner) {
        boolean logout = false;

        while (!logout) {
            System.out.println("\nStudent Actions:");
            System.out.println("1. Take Exam");
            System.out.println("2. Logout");
            System.out.print("Enter your choice: ");

            if (scanner.hasNextInt()) {
                int studentActionChoice = scanner.nextInt();
                scanner.nextLine();  // Consume newline

                switch (studentActionChoice) {
                    case 1:
                        takeExam(system, scanner);
                        break;
                    case 2:
                        System.out.println("Logging out...");
                        logout = true;
                        break;
                    default:
                        System.out.println("Invalid choice. Please choose a valid option.");
                }
            } else {
                System.out.println("Invalid input. Please enter a number.");
                scanner.nextLine();  // Clear invalid input
            }
        }
    }

    // Method for a student to take an exam
    private static void takeExam(ExamSystem system, Scanner scanner) {
        System.out.print("Enter your name: ");
        String studentName = scanner.nextLine();

        System.out.print("Choose a subject for the exam (e.g., Math/Programming): ");
        String subject = scanner.nextLine();

        Exam exam = system.createExam(subject, 5, 30);  // Example: 5 questions, 30-minute duration

        if (exam != null) {
            exam.startExam(studentName, system);
        } else {
            System.out.println("Unable to create exam. Please try again later.");
        }
    }
}
