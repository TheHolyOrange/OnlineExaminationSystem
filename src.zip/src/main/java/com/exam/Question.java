package main.java.com.exam;

public class Question {
    private String text;
    private String[] options;
    private int correctAnswerIndex;
    private String category;
    private String difficulty;

    public Question(String text, String[] options, int correctAnswerIndex, String category, String difficulty) {
        this.text = text;
        this.options = options;
        this.correctAnswerIndex = correctAnswerIndex;
        this.category = category;
        this.difficulty = difficulty;
    }

    public void setQuestionText(String text){
        this.text=text;
    }

    public void setCategory(String category){
        this.category=category;
    }

    public void setCorrectAnswerIndex(int correctAnswerIndex){
        this.correctAnswerIndex=correctAnswerIndex;
    }

    public void setOptions(String[] options){
        this.options=options;
    }
    
    public void setDifficulty(String difficulty){
        this.difficulty=difficulty;
    }

    public void displayQuestion() {
        System.out.println("Question: " + text);
        for (int i = 0; i < options.length; i++) {
            System.out.println((i + 1) + ": " + options[i]);
        }
    }

    public boolean checkAnswer(int selectedAnswerIndex) {
        return selectedAnswerIndex == correctAnswerIndex;
    }

    public String getCategory(){
        return category;
    }

    public String getQuestionText(){
        return text;
    }

    public String[] getOptions(){
        return options;
    }

    public int getCorrectAnswerIndex(){
        return correctAnswerIndex;
    }

    public String getDifficulty(){
        return difficulty;
    }

}
