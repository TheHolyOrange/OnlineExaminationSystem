package main.java.com.exam;

import java.text.SimpleDateFormat;
import java.util.*;

public class Exam {
    private List<Question> questions;
    private int duration; // in minutes

    public Exam(List<Question> questions, int duration) {
        this.questions = questions;
        this.duration = duration;
    }

    // Start the exam for a student and record the result
    public void startExam(String studentName, ExamSystem system) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("\nExam started. Duration: " + duration + " minutes.");

        int correctAnswers = 0;
        int incorrectAnswers = 0;

        for (Question question : questions) {
            question.displayQuestion();
            System.out.print("Enter your answer (1-" + question.getOptions().length + "): ");

            try {
                int answer = scanner.nextInt();
                scanner.nextLine(); // Consume newline

                if (question.checkAnswer(answer)) {
                    System.out.println("Correct!\n");
                    correctAnswers++;
                } else {
                    System.out.println("Incorrect. The correct answer was option " + question.getCorrectAnswerIndex() + ".\n");
                    incorrectAnswers++;
                }
            } catch (InputMismatchException e) {
                System.out.println("Invalid input. Please enter a number corresponding to your answer.\n");
                scanner.nextLine(); // Consume invalid input
                incorrectAnswers++;
            }
        }

        // After the exam
        String examDate = new SimpleDateFormat("yyyy-MM-dd").format(new Date());
        Result result = new Result(studentName, questions.get(0).getCategory(), questions.size(), correctAnswers, incorrectAnswers, examDate);
        system.saveResultToCSV(result);
        system.results.add(result); // Add to in-memory results

        System.out.println("Exam completed.");
        System.out.println("Correct Answers: " + correctAnswers);
        System.out.println("Incorrect Answers: " + incorrectAnswers + "\n");
    }
}
