package main.java.com.exam;

import java.io.IOException;
import java.util.NoSuchElementException;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        ExamSystem system = new ExamSystem();
        Scanner scanner = new Scanner(System.in);

        try {
            // Load existing users and questions from CSV files
            system.loadQuestionsFromCSV("src/main/resources/questions.csv");
            system.loadUsersFromCSV("src/main/resources/users.csv");

            // Load existing results from CSV
            system.loadResultsFromCSV();

            int choice = -1;

            // Main menu for user role selection
            while (choice != 3) {
                System.out.println("\nWelcome to the Online Examination System");
                System.out.println("1. Admin Menu");
                System.out.println("2. Student Menu");
                System.out.println("3. Exit");
                System.out.print("Enter your choice: ");

                // Input validation
                if (scanner.hasNextInt()) {
                    choice = scanner.nextInt();
                    scanner.nextLine();  // Consume the newline

                    if (choice == 1) {
                        Admin.handleAdminMenu(system, scanner);
                    } else if (choice == 2) {
                        Student.handleStudentMenu(system, scanner);
                    } else if (choice == 3) {
                        System.out.println("Exiting the system. Goodbye!");
                    } else {
                        System.out.println("Invalid choice. Please try again.");
                    }
                } else {
                    System.out.println("Invalid input. Please enter a valid number.");
                    scanner.nextLine();  // Clear invalid input
                }
            }
        } catch (IOException e) {
            System.out.println("Error loading data. Please check the CSV files.");
            e.printStackTrace();
        } catch (NoSuchElementException e) {
            System.out.println("No input found. Exiting system.");
        } finally {
            scanner.close();  // Ensure the scanner is closed properly
        }
    }    
}